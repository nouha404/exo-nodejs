const DATABASE = require('../database/produits.json');


exports.getAllCategories = (req, res) => {

  const categories = [];
  DATABASE.produits.forEach(produit => {
    produit.categories.forEach(category => {
      if (!categories.includes(category)) {
        categories.push(category);
      }
    });
  });
  res.json(categories);
};

exports.getCategoryById = (req, res) => {
  const categoryId = req.params.id;
};

exports.createCategory = (req, res) => {
  const { name } = req.body;
};

exports.updateCategory = (req, res) => {
  const categoryId = req.params.id;
  const { name } = req.body;
};


