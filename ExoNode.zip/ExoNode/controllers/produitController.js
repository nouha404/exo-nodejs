const fs = require('fs');
const path = require('path');
const DATABASE = require('../database/produits.json');


exports.getAllProducts = (req, res) => {
    res.status(200).json(DATABASE.produits);
};


exports.getProductById = (req, res) => {
    const productId = parseInt(req.params.id);
    const product = DATABASE.produits.find(product => product.id === productId);
    if (product) {
        res.status(200).json(product);
        console.log(product);
    } else {
        res.status(404).json({ error: 'Product not found' });
    }
};


exports.createProduct = (req, res) => {
    const newProduct = req.body;
    
    newProduct.id = DATABASE.produits.length + 1;
    DATABASE.produits.push(newProduct);

    
    fs.writeFile(path.join(__dirname, '../database/produits.json'), JSON.stringify(DATABASE, null, 2), (err) => {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            res.status(201).json(newProduct);
        }
    });
};


exports.updateProduct = (req, res) => {
    const productId = parseInt(req.params.id);
    const updatedProduct = req.body;
    const index = DATABASE.produits.findIndex(product => product.id === productId);
    if (index !== -1) {
        DATABASE.produits[index] = { ...DATABASE.produits[index], ...updatedProduct };
        fs.writeFile(path.join(__dirname, '../database/produits.json'), JSON.stringify(DATABASE, null, 2), (err) => {
            if (err) {
                console.error(err);
                res.status(500).json({ error: 'Internal Server Error' });
            } else {
                res.status(200).json(DATABASE.produits[index]);
            }
        });
    } else {
        res.status(404).json({ error: 'Product not found' });
    }
};



exports.deleteProduct = (req, res) => {
    const productId = parseInt(req.params.id);
    const index = DATABASE.produits.findIndex(product => product.id === productId);
    if (index !== -1) {
        DATABASE.produits.splice(index, 1);
        fs.writeFile(path.join(__dirname, '../database/products.json'), JSON.stringify(DATABASE, null, 2), (err) => {
            if (err) {
                console.error(err);
                res.status(500).json({ error: 'Internal Server Error' });
            } else {
                res.status(204).send();
            }
        });
    } else {
        res.status(404).json({ error: 'Product not found' });
    }
};
