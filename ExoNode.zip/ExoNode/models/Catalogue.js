class Catalogue {
    constructor(id, libelle) {
        this.id = id;
        this.libelle = libelle;
    }
}

module.exports = Catalogue;

