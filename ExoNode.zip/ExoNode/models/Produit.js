class Produit {
    constructor(id, libelle, prix, quantite, categories,  datePeremption) {
        this.id = id;
        this.libelle = libelle;
        this.prix = prix;
        this.quantite = quantite;
        this.categories = categories;
        this.datePeremption = datePeremption;
    }
}

module.exports = Produit;

/*
// models/Produit.js

const mongoose = require('mongoose');

const produitSchema = new mongoose.Schema({
    libelle: { type: String, required: true },
    prix: { type: Number, required: true },
    quantite: { type: Number, required: true },
    categories: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Category' }],
    datePeremption: { type: Date, default: null },
});

module.exports = mongoose.model('Produit', produitSchema);

*/