class Category {
    constructor(id, libelle) {
        this.id = id;
        this.libelle = libelle;
    }
}

module.exports = Category;