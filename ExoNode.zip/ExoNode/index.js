const express = require('express');

const produitRouter = require('./routes/produitRoutes');
const categoryRouter = require('./routes/categorieRoutes');
//const catalogueRouter = require('./routes/catalogueRoutes');

const app = express();
const port = 3000;

app.use('/produits', produitRouter);
app.use('/category', categoryRouter);
//app.use('/catalogues', catalogueRouter);


app.get('/', (req, res) => {
  res.send('Hello World!');
});


app.listen(port, () => {
  console.log(`Le serveur écoute sur http://localhost:${port}`);
});
