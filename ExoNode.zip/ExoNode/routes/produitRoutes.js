const express = require('express');
const router = express.Router();

const produitController = require('../controllers/produitController');

router.get('/', produitController.getAllProducts);
router.get('/:id', produitController.getProductById);
router.post('/create', produitController.createProduct);
router.put('/update/:id', produitController.updateProduct);
router.delete('/detelete/:id', produitController.deleteProduct);

module.exports = router;
