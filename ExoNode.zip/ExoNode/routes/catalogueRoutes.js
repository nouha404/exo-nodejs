const express = require('express');
const router = express.Router();

const catalogController = require('../controllers/catalogueController');

router.get('/', catalogController.getAllCatalogs);
router.get('/:name', catalogController.getCatalogByName);
router.post('/create', catalogController.createCatalog);
router.put('/update/:name', catalogController.updateCatalog);
router.delete('/delete/:name', catalogController.deleteCatalog);

module.exports = router;
